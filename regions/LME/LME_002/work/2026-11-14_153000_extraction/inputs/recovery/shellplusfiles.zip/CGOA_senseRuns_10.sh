# >>> Sense Runs without fitting first
#
#Crab simulations run with code compiled for CGOA model, requested by Nick Sagalkin ADFG, Crab PT, July 2010
#
#RANDOM RUN
# Tester to make sure it doesnt crash
#../src_fitted/ecosim -Mo -OCrabsims/CGOA_basedat1 -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KnoGOA_nofit_fitControl.csv -FnoGOA_fitData_09PT.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
# Now see what base fishing does to it(assuming full GOA effort scales appropriately for the CGOA as first cut)
# (files labeled basefishtest had old 2009 estimated catches, this has actual 2009 catch as basis for relative effort)
#../src_fitted/ecosim -Mo -OCrabsims/CGOA_basefish -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KnoGOA_nofit_fitControl.csv -FCGOA_Crabsims_baserun.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
#
# single runs for each scenario
#../src_fitted/ecosim -Mo -OCrabsims/CGOA_codmed -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KnoGOA_nofit_fitControl.csv -FCGOA_Crabsims_codmed.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
#../src_fitted/ecosim -Mo -OCrabsims/CGOA_atfmed -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KnoGOA_nofit_fitControl.csv -FCGOA_Crabsims_atfmed.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
#../src_fitted/ecosim -Mo -OCrabsims/CGOA_pollmed -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KnoGOA_nofit_fitControl.csv -FCGOA_Crabsims_pollmed.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
#../src_fitted/ecosim -Mo -OCrabsims/CGOA_allmed -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KnoGOA_nofit_fitControl.csv -FCGOA_Crabsims_allmed.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
#../src_fitted/ecosim -Mo -OCrabsims/CGOA_alllow -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KnoGOA_nofit_fitControl.csv -FCGOA_Crabsims_alllow.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
#../src_fitted/ecosim -Mo -OCrabsims/CGOA_allhigh -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KnoGOA_nofit_fitControl.csv -FCGOA_Crabsims_allhigh.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
#
#Crab simulations run with code compiled for CGOA model, requested by Nick Sagalkin ADFG, Crab PT, July 2010
#
# First generate base set of ecosystems with and without varying functional response (vul) parameters
#
#../src_fitted/ecosim -Me -Vv0.0 -OCrabsims/CGOA_basedat_novul -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KnoGOA_nofit_fitControl.csv -FnoGOA_fitData_09PT.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
#../src_fitted/ecosim -Me -Vv6.0 -OCrabsims/CGOA_basedat_vul -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KnoGOA_nofit_fitControl.csv -FnoGOA_fitData_09PT.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S50000 -B50 -R0 -Vs1.0 -Vh1.0
#
# Then run the scenarios both with and without varying vuls, including a baserun for differencing
#
../src_fitted/ecosim -Mi -Vv0.0 -ICrabsims/CGOA_basedat_novul -OCrabsims/base/CGOA_novul_baserun -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_baserun.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
../src_fitted/ecosim -Mi -Vv0.0 -ICrabsims/CGOA_basedat_novul -OCrabsims/allhigh/CGOA_novul_allhigh -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_allhigh.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
../src_fitted/ecosim -Mi -Vv0.0 -ICrabsims/CGOA_basedat_novul -OCrabsims/alllow/CGOA_novul_alllow -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_alllow.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
../src_fitted/ecosim -Mi -Vv0.0 -ICrabsims/CGOA_basedat_novul -OCrabsims/allmed/CGOA_novul_allmed -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_allmed.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
../src_fitted/ecosim -Mi -Vv0.0 -ICrabsims/CGOA_basedat_novul -OCrabsims/atfmed/CGOA_novul_atfmed -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_atfmed.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
../src_fitted/ecosim -Mi -Vv0.0 -ICrabsims/CGOA_basedat_novul -OCrabsims/codmed/CGOA_novul_codmed -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_codmed.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
../src_fitted/ecosim -Mi -Vv0.0 -ICrabsims/CGOA_basedat_novul -OCrabsims/pollmed/CGOA_novul_pollmed -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_pollmed.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
#
../src_fitted/ecosim -Mi -Vv6.0 -ICrabsims/CGOA_basedat_vul -OCrabsims/base/CGOA_vul_baserun -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_baserun.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
../src_fitted/ecosim -Mi -Vv6.0 -ICrabsims/CGOA_basedat_vul -OCrabsims/allhigh/CGOA_vul_allhigh -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_allhigh.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
../src_fitted/ecosim -Mi -Vv6.0 -ICrabsims/CGOA_basedat_vul -OCrabsims/alllow/CGOA_vul_alllow -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_alllow.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
../src_fitted/ecosim -Mi -Vv6.0 -ICrabsims/CGOA_basedat_vul -OCrabsims/allmed/CGOA_vul_allmed -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_allmed.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
../src_fitted/ecosim -Mi -Vv6.0 -ICrabsims/CGOA_basedat_vul -OCrabsims/atfmed/CGOA_vul_atfmed -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_atfmed.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
../src_fitted/ecosim -Mi -Vv6.0 -ICrabsims/CGOA_basedat_vul -OCrabsims/codmed/CGOA_vul_codmed -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_codmed.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0
../src_fitted/ecosim -Mi -Vv6.0 -ICrabsims/CGOA_basedat_vul -OCrabsims/pollmed/CGOA_vul_pollmed -DnoDietFits.csv -PGOA_fitVectorsStart.csv -KGOA_nofit_fitControl.csv -FCGOA_Crabsims_pollmed.csv -JGOA_stanzas_in_SAagg.csv -Cno_climate_in.csv -S10000 -B50 -R0 -Vs1.0 -Vh1.0

