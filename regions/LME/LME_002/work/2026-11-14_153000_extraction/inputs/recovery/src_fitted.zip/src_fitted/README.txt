
FILE For notetaking begun May 21 2008

SKG recompiled for GOA sense runs June 2 2008, in folder GOA_sensetest
temporarily turning off variation in dynamic parameters by setting vulvar=0.0 in ecosim_threads.cpp line 1917
altered save_a_series to print end file with burn time for saved systems
altered load_a_series to remove call to path_to_rates

KYA depreciated random_ecosystem_series and replaced with random_fromfitted, must use fitting file

SKG temporarily turned off variation in adult juvenile parameters 
    adult juv variation turned back on (June 3)

corrected both header files for GOA and EBS to have pedigree and correct model

SKG recompiled for EBS sense runs June 3 2008, in folder EBS_random

SKG added functions perturb_loaded_series and load_and_perturb_series June 4, emulating sense outputs

KYA showed SKG how to fix mistakes in load_and_perturm_series June 9, which now works

KYA June 10 2008
   -Some code cleanup
    -Removed longdata.cpp from project (non-functional)
	  -Moved threaded sense routines into sense.cpp
    -Moved some of Kerim's experiments to simlabs.cpp
    -Merged gsm compilation into makefile, gsm useable where installed
    -Path Trophic Levels for non-fisheries are now calculated at 
	   beginning of run, and stored in global variable TL[sp].
	  -Added the extremely useful run mode K.
    
SKG June 13 2008
changed perturbation in sense.cpp to 0.9M and re-running for both systems

SKG June 15 2008
changed perturbation in sense.cpp to 1.2M and re-running for both systems

SKG June 16 2008
changed perturbation in sense.cpp to 0.8M and re-running for both systems

SKG July 3 2008
changed perturbation in sense.cpp to 1.3M and re-running for both systems

SKG July 4 2008
changed perturbation in sense.cpp to 0.7M and re-running for both systems

SKG July 6 2008
changed perturbation in sense.cpp to 1.4M and re-running for both systems

SKG July 8 2008
changed perturbation in sense.cpp to 0.6M and re-running for both systems
