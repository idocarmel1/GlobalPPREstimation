# Clear everything (optional)
#rm(list=ls())

# Set working directory -----------------------------------------------------------------------
setwd("C:/Users/stevenp/OneDrive - VLIZ/Documents/stevenp/Ecopath with Ecosim/EMBENS Rpath")

# Packages ------------------------------------------------------------------------------------
require(data.table)
# Rpath is also needed
# Lucey et al. (2020) https://doi.org/10.1016/j.ecolmodel.2020.109057
# Rpakage on Github: https://github.com/NOAA-EDAB/Rpath
# install R package devtools::install_github("NOAA-EDAB/Rpath")
require(Rpath)

# Run Rpath (unbalanced) ------------------------------------------------------------------------
source("EMBENS Rpath - Rpath run.R")

# Adjust input parameters to balance Ecopath --------------------------------------------------
# input parameters
## remark: Large crabs + shrimp biomass = 5.15 (Rpath), in Ecopath biomass 5.1 -> balanced model
EMBENS_param$model[c(1:38),c(3:7)] <- read.csv("data/balanced/EMBENS - input - balanced ecopath model.csv", header = TRUE, sep = ";", stringsAsFactors = FALSE)[,-1]

#stanzas
EMBENS_param$stanzas$stindiv[,c(7, 9:11)] <- read.csv("data/balanced/EMBENS - stanzas - balanced ecopath model.csv", header = TRUE, sep = ";", stringsAsFactors = FALSE)[,-1]
EMBENS_param2 <- rpath.stanzas(EMBENS_param)
# plot stanzas
stanzaplot_SP(EMBENS_param2, TotalStanzaGroups = 6) # original function: stanzaplot(EMBENS_param2, StanzaGroup = 4)

#diet
EMBENS_param2$diet[, c(2:36)] <- read.csv("data/balanced/EMBENS - diet - balanced ecopath model.csv", header = TRUE, sep = ";", stringsAsFactors = FALSE)[,-1]

# Check input parameters' file -------------------------------------------------------------------
check.rpath.params(EMBENS_param2)

#######################################
#                Rpath                #
#######################################
# Run Rpath ------------------------------------------------------------------------------------
EMBENS_param_Rpath_balanced <- rpath(EMBENS_param2, eco.name = "southern North Sea (ICES area IVc)", eco.area = 63633.6)
EMBENS_param_Rpath_balanced

## Plot flow diagram
par(mfrow=c(1,1)) # get 1 plot in the window again
EMBENS_flowdiagram <- webplot(EMBENS_param_Rpath_balanced, eco.name = attr(EMBENS_param_Rpath, 'eco.name'), line.col = 'grey',
                              highlight = NULL, highlight.col = c('black', 'red', 'orange'),
                              labels = TRUE, label.pos = NULL, label.num = TRUE, label.cex = 1,
                              fleets = TRUE, type.col = 'black', box.order = NULL)

#EMBENS_flowdiagram_pelagic_fish <- webplot(EMBENS_param_Rpath_balanced, eco.name = attr(EMBENS_param_Rpath_balanced, 'eco.name'), highlight = "Sole (adult)", line.col = 'grey', highlight.col = c('black', 'red', 'orange'), labels = TRUE, label.pos = 1, label.num = TRUE, label.cex = 1, fleets = TRUE, type.col = 'black', box.order = NULL)


## Save your Rpath file
if(!dir.exists("results/balanced")) dir.create("results/balanced") #create results folder if it doesn't exist yet
if(!dir.exists(paste0("results/balanced/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET")))) dir.create(paste0("results/balanced/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"))) #create results file for current date if it doesn't exist yet
write.Rpath(EMBENS_param_Rpath,file = paste0("results/balanced/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/Rpath Overview - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv")) # .csv file or use .Rdata for R file
write.csv(EMBENS_param2$model,file = paste0("results/balanced/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/EMBENS Rpath param - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv"),row.names=FALSE) # .csv file or use .Rdata for R file
write.csv(EMBENS_param_Rpath$Landings,file = paste0("results/balanced/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/EMBENS Rpath Landings - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv")) # .csv file or use .Rdata for R file
write.csv(EMBENS_param_Rpath$Discards,file = paste0("results/balanced/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/EMBENS Rpath Discards - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv")) # .csv file or use .Rdata for R file

