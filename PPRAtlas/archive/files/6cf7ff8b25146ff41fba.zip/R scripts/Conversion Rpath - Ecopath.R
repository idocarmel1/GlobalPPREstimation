# Conversion Rpath to Ecopath format ----------------------------------------------------
Rpath_to_ecopath <- function(Rpath_input_file, Rpath_output_file){
  # convert to df
  Rpath_input_file$model <- as.data.frame(Rpath_input_file$model)

  # Get FG & Fishery names
  FG_names <- subset(Rpath_input_file$model$Group,Rpath_input_file$model$Type != 3)
  Fishery_names <- subset(Rpath_input_file$model$Group,Rpath_input_file$model$Type == 3)

  # ECOPATH INPUT DATA
  # df with FG input data
  # Create df with FGs names
  ecopath_param <- data.frame("Group name" = c(FG_names),
                              "Hab area (proportion)" = 1,
                              "Biomass in habitat area (t/km²)" = NA,
                              "Total mortality (/year)" = NA,
                              "Production / biomass (/year)" = NA,
                              "Consumption / biomass (/year)" = NA,
                              "Ecotrophic Efficiency" = NA,
                              "Other mortality" = NA,
                              "Production / consumption" = NA,
                              "Unassim. consumption" = c(rep(0.2,length(FG_names) - length(which(Rpath_input_file$model$Type == 1 | Rpath_input_file$model$Type == 2))),
                                                         (rep(0,length(which(Rpath_input_file$model$Type == 1 | Rpath_input_file$model$Type == 2))))),
                              "Detritus import (t/km²/year)" = NA)

  colnames(ecopath_param) <- c("Group name",
                               "Hab area (proportion)",
                               "Biomass in habitat area (t/km²)",
                               "Total mortality (/year)",
                               "Production / biomass (/year)",
                               "Consumption / biomass (/year)",
                               "Ecotrophic Efficiency",
                               "Other mortality",
                               "Production / consumption",
                               "Unassim. consumption",
                               "Detritus import (t/km²/year)")
  rownames(Rpath_input_file$model) <- c(FG_names,Fishery_names)


  # fill in df
  ## Biomass
  ecopath_param$`Biomass in habitat area (t/km²)` <- Rpath_input_file$model[FG_names,"Biomass"]
  ## PB
  ecopath_param$`Production / biomass (/year)`[which(!FG_names %in% Rpath_input_file$stanzas$stindiv$Group)] <- Rpath_input_file$model[which(!FG_names %in% Rpath_input_file$stanzas$stindiv$Group),"PB"]
  ## Z
  ecopath_param$`Total mortality (/year)`[which(FG_names %in% Rpath_input_file$stanzas$stindiv$Group)] <- Rpath_input_file$model[which(FG_names %in% Rpath_input_file$stanzas$stindiv$Group),"PB"]
  ## QB
  ecopath_param$`Consumption / biomass (/year)` <- Rpath_input_file$model[FG_names,"QB"]
  ## EE
  ecopath_param$`Ecotrophic Efficiency`<- Rpath_input_file$model[FG_names,"EE"]
  ## Detritus Import
  ecopath_param$`Detritus import (t/km²/year)`[which(Rpath_input_file$model$Type == 2)] <- 0
  ## PQ
  ecopath_param$`Production / consumption`<- Rpath_input_file$model[FG_names,"ProdCons"]

  # df with landings
  ecopath_landings <- Rpath_input_file$model[FG_names,c(13:(12+length(Fishery_names)))]
  ecopath_landings <- cbind(FG_names,ecopath_landings)
  colnames(ecopath_landings) <- c("Group name",Fishery_names)

  # df with discards
  ecopath_discards <- Rpath_input_file$model[FG_names,c((13+length(Fishery_names)):length(colnames(Rpath_input_file$model)))]
  ecopath_discards <- cbind(FG_names,ecopath_discards)
  colnames(ecopath_discards) <- c("Group name",Fishery_names)

  # df with diets
  ecopath_diet <- Rpath_input_file$diet

  # df with stanza info
  ecopath_stanza <- Rpath_input_file$stanzas$stindiv[,c(4,5,7:9,11)]

  # write .csv files in folder "Ecopath files" with subfolder of current date
  if(!dir.exists("Ecopath files")) dir.create("Ecopath files") #create "Ecopath files" folder if it doesn't exist yet
  if(!dir.exists(paste0("Ecopath files/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET")))) dir.create(paste0("Ecopath files/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"))) # create results file for current date if it doesn't exist yet

  write.csv(ecopath_param,file = paste0("Ecopath files/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/Ecopath Parameters - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv"), row.names = FALSE)
  write.csv(ecopath_landings,file = paste0("Ecopath files/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/Ecopath Landings - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv"), row.names = FALSE)
  write.csv(ecopath_discards,file = paste0("Ecopath files/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/Ecopath Discards - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv"), row.names = FALSE)
  write.csv(ecopath_diet,file = paste0("Ecopath files/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/Ecopath Diets - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv"), row.names = FALSE)
  write.csv(ecopath_stanza,file = paste0("Ecopath files/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/Ecopath Stanza - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv"), row.names = FALSE)


  if (!is.na(Rpath_output_file[1])){
  # RPATH OUTPUT DATA in ECOPATH FORMAT
  # df with Rpath output data
  # Create df with FGs names
  ecopath_param_output <- data.frame("Group name" = c(FG_names),
                                     "Hab area (proportion)" = 1,
                                     "Biomass in habitat area (t/km²)" = NA,
                                     "Total mortality (/year)" = NA,
                                     "Production / biomass (/year)" = NA,
                                     "Consumption / biomass (/year)" = NA,
                                     "Ecotrophic Efficiency" = NA,
                                     "Other mortality" = NA,
                                     "Production / consumption" = NA,
                                     "Unassim. consumption" = c(rep(0.2,length(FG_names) - length(which(Rpath_output_file$type == 1 | Rpath_output_file$type == 2))),
                                                                (rep(0,length(which(Rpath_output_file$type == 1 | Rpath_output_file$type == 2))))),
                                     "Detritus import (t/km²/year)" = NA)

  colnames(ecopath_param_output) <- c("Group name",
                                      "Hab area (proportion)",
                                      "Biomass in habitat area (t/km²)",
                                      "Total mortality (/year)",
                                      "Production / biomass (/year)",
                                      "Consumption / biomass (/year)",
                                      "Ecotrophic Efficiency",
                                      "Other mortality",
                                      "Production / consumption",
                                      "Unassim. consumption",
                                      "Detritus import (t/km²/year)")


  # fill in df
  ## Biomass
  ecopath_param_output$`Biomass in habitat area (t/km²)` <- Rpath_output_file$Biomass[FG_names]
  ## PB
  ecopath_param_output$`Production / biomass (/year)` <- Rpath_output_file$PB[FG_names]
  ## Z
  ecopath_param_output$`Total mortality (/year)` <- Rpath_output_file$PB[FG_names]
  ## QB
  ecopath_param_output$`Consumption / biomass (/year)` <- Rpath_output_file$QB[FG_names]
  ## EE
  ecopath_param_output$`Ecotrophic Efficiency`<- Rpath_output_file$EE[FG_names]
  ## Detritus Import
  ecopath_param_output$`Detritus import (t/km²/year)`[which(Rpath_output_file$type == 2)] <- 0
  ecopath_param_output$`Production / consumption`<- Rpath_output_file$GE[FG_names]

  # write .csv files in folder "Ecopath files" with subfolder of current date
  write.csv(ecopath_param_output,file = paste0("Ecopath files/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/Results Ecopath (output) - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv"), row.names = FALSE)
  }

  # export of dfs
  if (is.na(Rpath_output_file[1])){
    # create a list with output df names
    list_with_output_dfs <- c("ecopath_param","ecopath_landings","ecopath_discards","ecopath_diet","ecopath_stanza")
    return(list("df_names" = list_with_output_dfs,
              "ecopath_param" = ecopath_param,
              "ecopath_landings" = ecopath_landings,
              "ecopath_discards" = ecopath_discards,
              "ecopath_diet" = ecopath_diet,
              "ecopath_stanza" = ecopath_stanza))
  } else {
    list_with_output_dfs <- c("ecopath_param","ecopath_landings","ecopath_discards","ecopath_diet","ecopath_stanza","ecopath_param_output")
    return(list("df_names" = list_with_output_dfs,
                "ecopath_param" = ecopath_param,
                "ecopath_landings" = ecopath_landings,
                "ecopath_discards" = ecopath_discards,
                "ecopath_diet" = ecopath_diet,
                "ecopath_stanza" = ecopath_stanza,
                "ecopath_param_output" = ecopath_param_output))
  }
}

