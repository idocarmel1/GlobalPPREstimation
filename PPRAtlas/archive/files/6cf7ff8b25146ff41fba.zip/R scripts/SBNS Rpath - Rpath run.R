# Clear everything (optional)
#rm(list=ls())

# Set working directory -----------------------------------------------------------------------
setwd("C:/Users/stevenp/OneDrive - VLIZ/Documents/stevenp/Ecopath with Ecosim/EMBENS Rpath")

# Packages ------------------------------------------------------------------------------------
require(data.table)
# Rpath is also needed
# Lucey et al. (2020) https://doi.org/10.1016/j.ecolmodel.2020.109057
# Rpakage on Github: https://github.com/NOAA-EDAB/Rpath
# install R package devtools::install_github("NOAA-EDAB/Rpath")
require(Rpath)

# Load Rpath functions ------------------------------------------------------------------------
#source("Rpath-master/R/param.R")
#source("Rpath-master/R/ecopath.R")
source("Rpath-master/R/ecopath_plot.R")
source("Rpath-master/R/write_functions.R")
source("Rpath-master/R/write_functions.R")
source("Conversion Rpath - Ecopath.R")

#######################################
#       Rpath parameter's file        #
#######################################
# Create Rpath parameter file -----------------------------------------------------------------
param_data <- read.csv("data/parameters Rpath - 01042021.csv", header = TRUE, stringsAsFactors = FALSE)
stanza_data <- read.csv("data/Stanza groups info - 31032021.csv", header = TRUE, stringsAsFactors = FALSE)

EMBENS_param <- create.rpath.params(param_data$group, param_data$type, param_data$stgroup)

# Load parameter data --------------------------------------------------------------------------
source("EMBENS Rpath - Diets.R")
source("EMBENS Rpath - Fisheries.R") # or if you're interested to know the fleets ratio of the catch by country use source("EMBENS Rpath - Fisheries (with countries).R")
                                        # warnings messages from NA introduced comes from character such as "." and "-" that become NA when transformed to numerical
source("EMBENS Rpath - FG input data.R")  # gives warnings, but it's okay when it is the warning: In na.omit(as.numeric(landing_cod_IVc[, i])) : NAs introduced by coercion

# Insert parameter data ------------------------------------------------------------------------
## Functional groups
for(i in rownames(empirical_requirements)){
  EMBENS_param$model[Group %in% i,Biomass := empirical_requirements[i,"B"]]
  EMBENS_param$model[Group %in% i,PB := empirical_requirements[i,"PB"]]
  EMBENS_param$model[Group %in% i,QB := empirical_requirements[i,"QB"]]
  EMBENS_param$model[Group %in% i,EE := empirical_requirements[i,"EE"]]
  EMBENS_param$model[Group %in% i,ProdCons := empirical_requirements[i,"PQ"]]
  if(!is.na(EMBENS_param$model[Group %in% i,QB]) & !is.na(EMBENS_param$model[Group %in% i,Biomass]) &
     !is.na(EMBENS_param$model[Group %in% i,PB])){      # to remove the earlier calculated PQ as a control step.
    EMBENS_param$model[Group %in% i,ProdCons := NA]
  }
  if(i %in% stanza_data$Group){
    EMBENS_param$model[Group %in% i,PB := stanza_data[which(stanza_data$Group %in% i),"Z"]]
  }
}

EMBENS_param$model[Group %in% "Pelagic fish",Biomass := NA] # remove B from Pelagic fish -> NA
EMBENS_param$model[, Detritus := c(rep(1,36),rep(0,17))]
EMBENS_param$model[, Discards := c(rep(0,38),rep(1,15))]
EMBENS_param$model[, BioAcc := c(rep(0,38),rep(NA,15))]
EMBENS_param$model[, Unassim := c(rep(0.2,35),rep(0,3),rep(NA,15))]
#EMBENS_param$model[, DetInput := c(rep(NA,36),0,0,rep(NA,15))]

## Fisheries
for(i in colnames(comm_fishery)){
  EMBENS_param$model[c(1:31,33:38),i] <-  comm_fishery[,i]
}
EMBENS_param$model[32,"Aquaculture (blue mussels)"] <- 0.0000000000001 # fill in aquaculture harvest (blue mussels on row 32)
EMBENS_param$model[32,"Aquaculture (blue mussels).disc"] <- 0 # fill in aquaculture discard (blue mussels on row 32)
#insert low values for recr. fishery
EMBENS_param$model[c(1:38),c(23:27,38:42)] <- read.csv("data/EMBENS recr fishery.csv", header = TRUE, stringsAsFactors = FALSE)

## Diets
EMBENS_param$diet[c(1:39),c(2:36)] <- diet_IVc[c(1:39),c(1:35)]  # start to fill in from col 2 in diet file as col 1 is group names
EMBENS_param$diet[c(1:39),37] <- 0 # phytoplankton

## Stanza groups
# IMPORTANT that juvenile come first
for (j in na.omit(unique(stanza_data$StanzaGroup))){
  EMBENS_param$stanzas$stgroups$VBGF_Ksp[EMBENS_param$stanzas$stgroups$StanzaGroup %in% j] <- stanza_data[which(stanza_data$StanzaGroup %in% j),"K"]
  EMBENS_param$stanzas$stgroups$Wmat[EMBENS_param$stanzas$stgroups$StanzaGroup %in% j] <- stanza_data[which(stanza_data$StanzaGroup %in% j),"Wmat"]
}

for (k in stanza_data$Group){
  #EMBENS_param$stanzas$stindiv$StanzaNum[which(EMBENS_param$stanzas$stindiv$Group %in% k)] <- stanza_data[which(stanza_data$Group %in% k),"StanzaNum"]]
  EMBENS_param$stanzas$stindiv$Z[which(EMBENS_param$stanzas$stindiv$Group %in% k)] <- stanza_data[which(stanza_data$Group %in% k),"Z"]
  EMBENS_param$stanzas$stindiv$First[which(EMBENS_param$stanzas$stindiv$Group %in% k)] <- stanza_data[which(stanza_data$Group %in% k),"First"]
  EMBENS_param$stanzas$stindiv$Last[which(EMBENS_param$stanzas$stindiv$Group %in% k)] <- stanza_data[which(stanza_data$Group %in% k),"Last"]
  EMBENS_param$stanzas$stindiv$Leading[which(EMBENS_param$stanzas$stindiv$Group %in% k)] <- stanza_data[which(stanza_data$Group %in% k),"Leading"]
}

# calculate stanzas parameters
EMBENS_param$stanzas$stgroups$VBGF_Ksp[4] <- 0.12 # change K for plaice with median of fishbase instead of fishbase (mean) value
EMBENS_param2 <- rpath.stanzas(EMBENS_param)
# plot stanzas
stanzaplot_SP(EMBENS_param2, TotalStanzaGroups = 6) # original function: stanzaplot(EMBENS_param2, StanzaGroup = 4)

# Check input parameters' file -------------------------------------------------------------------
check.rpath.params(EMBENS_param2)

#######################################
#                Rpath                #
#######################################
# Run Rpath ------------------------------------------------------------------------------------
EMBENS_param_Rpath <- rpath(EMBENS_param2, eco.name = "southern North Sea (ICES area IVc)", eco.area = 1)
EMBENS_param_Rpath

## Plot flow diagram
par(mfrow=c(1,1)) # get 1 plot in the window again
EMBENS_flowdiagram <- webplot(EMBENS_param_Rpath, eco.name = attr(EMBENS_param_Rpath, 'eco.name'), line.col = 'grey',
                                  highlight = NULL, highlight.col = c('black', 'red', 'orange'),
                                  labels = TRUE, label.pos = NULL, label.num = TRUE, label.cex = 1,
                                  fleets = TRUE, type.col = 'black', box.order = NULL)

#EMBENS_flowdiagram_pelagic_fish <- webplot(EMBENS_param_Rpath, eco.name = attr(EMBENS_param_Rpath, 'eco.name'), highlight = "Sole (adult)", line.col = 'grey', highlight.col = c('black', 'red', 'orange'), labels = TRUE, label.pos = 1, label.num = TRUE, label.cex = 1, fleets = TRUE, type.col = 'black', box.order = NULL)


## Save your Rpath file
if(!dir.exists("results")) dir.create("results") #create results folder if it doesn't exist yet
if(!dir.exists(paste0("results/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET")))) dir.create(paste0("results/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"))) #create results file for current date if it doesn't exist yet
write.Rpath(EMBENS_param_Rpath,file = paste0("results/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/Rpath Overview - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv")) # .csv file or use .Rdata for R file
write.csv(EMBENS_param2$model,file = paste0("results/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/EMBENS Rpath param - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv"),row.names=FALSE) # .csv file or use .Rdata for R file
write.csv(EMBENS_param_Rpath$Landings,file = paste0("results/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/EMBENS Rpath Landings - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv")) # .csv file or use .Rdata for R file
write.csv(EMBENS_param_Rpath$Discards,file = paste0("results/",format(Sys.Date(), format = "%d-%m-%Y", tz = "CET"),"/EMBENS Rpath Discards - ",format(Sys.Date(), format = "%d%m%Y", tz = "CET"),".csv")) # .csv file or use .Rdata for R file

# Conversion to Ecopath format
Ecopath_param <- Rpath_to_ecopath(EMBENS_param2,EMBENS_param_Rpath) # function(Rpath_input_file, Rpath_output_file)
